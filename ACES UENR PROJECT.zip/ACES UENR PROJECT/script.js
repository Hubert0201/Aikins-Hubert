// Search Form Validation
document.getElementById('searchForm').addEventListener('submit', function(event) {
    let searchInput = document.getElementById('searchInput').value;
    if (searchInput.trim() === "") {
        alert("Please enter a search term.");
        event.preventDefault();
    }
});

// Navigation Click Alert
document.querySelectorAll('.nav_links a').forEach(link => {
    link.addEventListener('click', function(event) {
        alert('You clicked: ' + this.textContent);
    });
});

// Dark Mode Toggle
document.getElementById('darkModeToggle').addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
    if (document.body.classList.contains('dark-mode')) {
        localStorage.setItem('theme', 'dark');
    } else {
        localStorage.setItem('theme', 'light');
    }
});

// Apply Dark Mode on Load
if (localStorage.getItem('theme') === 'dark') {
    document.body.classList.add('dark-mode');
}